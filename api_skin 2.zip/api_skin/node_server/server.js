// server.js
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 8080;
 
app.use(cors());
app.use(express.json());

 
app.use(cors()); app.use(express.json());
 
// Session-based step tracking 
const sessionState = {}; // sessionId => { flow: 'bank', stepIndex: 0 }
 
// Define ordered flow steps 
const bankSteps = [ 'start bank', 'open account', 'account selected', 'name entered', 'phone entered', 'email entered', 'preferences set', 'contact set', 'alert threshold set', 'submit', 'confirm' ];
 
const tradeSteps = [ 'start trade', 'select market', 'market chosen', 'symbol entered', 'price', 'buy/sell', 'order type', 'select quantity', 'place order', 'order placed' ];
 
const travelSteps = [ 'start travel', 'select destination', 'destination chosen', 'interests', 'dates', 'budget', 'hotel', 'confirm travel', 'travel booked' ];
 
const bankFlow = {
    'start bank': [
      { type: 'text', text: '🏦 Welcome to Flutter Bank!' },
      { type: 'card', text: 'Open an account, check balance, get alerts.' },
      {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn-icons-png.flaticon.com/512/633/633611.png"
      }
       ,
      
    ],
    'open account': [
      {
        type: 'radio_group',
        options: [
          { label: 'Savings', value: 'savings' },
          { label: 'Current', value: 'current' },
          { label: 'NRI', value: 'nri' }
        ]
      }
    ],
    'name entered': [ { type: 'textfield', label: 'Enter your phone number' } ],
    
    'email entered': [
      {
        type: 'checkbox_group',
        options: [
          { label: 'Email', value: 'email' },
          { label: 'SMS', value: 'sms' },
          { label: 'Push', value: 'push' }
        ]
      }
    ],
    'phone entered': [ { type: 'textfield', label: 'Enter your email address' } ],

    
    'preferences set': [
      {
        type: 'dropdown',
        label: 'Preferred Contact Method',
        options: [
          { label: 'Phone', value: 'phone' },
          { label: 'Email', value: 'email' },
          { label: 'SMS', value: 'sms' }
        ]
      }
    ],
    'contact set': [
      {
        type: 'slider',
        label: 'Set alert threshold',
        min: 0,
        max: 100000,
        divisions: 10,
        value: 50000
      },
      { type: "form",  "fields": [
        {
          "type": "text",
          "text": "Enter your full name"
        },
      
      {
        "type": "image",
        "text": "Your account summary snapshot",
        "url": "https://cdn.pixabay.com/photo/2016/11/29/09/32/beach-1867285_960_720.jpg"
     },
       
        {
          "type": "radio_group",
          "text": "Select gender",
          "options": [
            { "label": "Male", "value": "male" },
            { "label": "Female", "value": "female" },
            { "label": "Other", "value": "other" }
          ]
        },
        {
          "type": "checkbox_group",
          "text": "Select gender",
          "options": [
            { "label": "Male", "value": "male" },
            { "label": "Female", "value": "female" },
            { "label": "Other", "value": "other" }
          ]
        },
        {
          "type": "dropdown",
          "text": "Choose your country",
          "options": [
            { "label": "India", "value": "in" },
            { "label": "USA", "value": "us" },
            { "label": "Germany", "value": "de" }
          ]
        },
        {
          "type": "button",
          "text": "Submit"
        }
      ] },
    ],
    'alert threshold set': [
      { type: 'card', text: 'Monthly Statement: ₹25,000 spent' },
      {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
      }
       
      
    ],
    'submit': [ { type: 'button', label: 'Submit Application', action: 'submitted' } ],
    'confirm': [ { type: 'alert', title: 'Success!', message: 'Your bank account is created.' } ]
  };
   
  // 📈 Trade Flow
  const tradeFlow = {
    'start trade': [
      { type: 'text', text: '📈 Welcome to Flutter Trading Bot!' },
      { type: 'card', text: 'Trade stocks, set alerts, view portfolio.' },
      {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn-icons-png.flaticon.com/512/1170/1170576.png"
      }
       
    ],
    'select market': [
      {
        type: 'dropdown',
        label: 'Select Market',
        options: [
          { label: 'NSE', value: 'nse' },
          { label: 'BSE', value: 'bse' },
          { label: 'NASDAQ', value: 'nasdaq' }
        ]
      }
    ],
    
    'market chosen': [ { type: 'textfield', label: 'Enter Stock Symbol (e.g. INFY)' },
    { type: "shimmer", text: "Loading market data..." },
    { type: "switch", text: "Enable Price Alerts?" },
        { type: "chart", chartType: "bar", data: [50, 75, 90, 30] }

],
    'symbol entered': [ {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
      }
       ],
    'price': [ { type: 'card', text: 'INFY Current Price: ₹1,580' } ],
    'buy/sell': [
      {
        type: 'radio_group',
        options: [
          { label: 'Buy', value: 'buy' },
          { label: 'Sell', value: 'sell' }
        ]
      }
    ],
    'order type': [
      {
        type: 'dropdown',
        label: 'Order Type',
        options: [
          { label: 'Market', value: 'market' },
          { label: 'Limit', value: 'limit' },
          { label: 'Stop', value: 'stop' }
        ]
      }
    ],
    'select quantity': [
      {
        type: 'slider',
        label: 'Quantity',
        min: 0,
        max: 100,
        divisions: 10,
        value: 10
      }
    ],
    'place order': [ { type: 'button', label: 'Place Trade', action: 'trade_placed' } ],
    'order placed': [ { type: 'alert', title: 'Trade Successful', message: 'Your order has been placed.' } ]
  };
   
  // ✈️ Travel Flow
  const travelFlow = {
    'start travel': [
      { type: 'text', text: '✈️ Let\'s plan your next trip!' },
      {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn.pixabay.com/photo/2015/01/08/18/29/airplane-593587_960_720.jpg"
      }
       
    ],
    'select destination': [
      {
        type: 'dropdown',
        label: 'Choose Destination',
        options: [
          { label: 'Paris', value: 'paris' },
          { label: 'Tokyo', value: 'tokyo' },
          { label: 'Dubai', value: 'dubai' }
        ]
      }
    ],
    'destination chosen': [
      {
        type: 'radio_group',
        options: [
          { label: 'Solo', value: 'solo' },
          { label: 'Family', value: 'family' },
          { label: 'Friends', value: 'friends' }
        ]
      }
    ],
    'interests': [
      {
        type: 'checkbox_group',
        options: [
          { label: 'Beach', value: 'beach' },
          { label: 'Mountain', value: 'mountain' },
          { label: 'Food Tour', value: 'food' }
        ]
      }
    ],
    'dates': [ { type: 'textfield', label: 'Enter travel dates' } ],
    'budget': [
      {
        type: 'slider',
        label: 'Select Budget',
        min: 10000,
        max: 100000,
        divisions: 9,
        value: 50000
      }
    ],
    'hotel': [
      { type: 'card', text: 'Hotel Bliss, 4-star, ₹3,500/night' },
       {
        type: "image",
        text: "Your account summary snapshot",
        url: "https://cdn.pixabay.com/photo/2016/11/29/09/32/beach-1867285_960_720.jpg"
      }
       
    ],
    'confirm travel': [ { type: 'button', label: 'Book Now', action: 'booked' } ],
    'travel booked': [ { type: 'alert', title: '🎉 Booking Confirmed', message: 'Your trip is booked!' } ]
  };
// 🆘 Help Flow
const helpFlow = {
    'help': [
      { type: 'text', text: '🤖 *Welcome to Flutter Chatbot Help*' },
      
      {
        type: 'card',
        text:
          ' *Banking Flow Steps:*\n'
          + '1. start bank\n'
          + '2. open account\n'
          + '3. account selected\n'
          + '4. name entered\n'
          + '5. phone entered\n'
          + '6. email entered\n'
          + '7. preferences set\n'
          + '8. contact set\n'
          + '9. alert threshold set\n'
          + '10. submit\n'
          + '11. confirm'
      },
   
      {
        type: 'card',
        text:
          '*Trade Flow Steps:*\n'
          + '1. start trade\n'
          + '2. select market\n'
          + '3. market chosen\n'
          + '4. symbol entered\n'
          + '5. price\n'
          + '6. buy/sell\n'
          + '7. order type\n'
          + '8. select quantity\n'
          + '9. place order\n'
          + '10. order placed'
      },
   
      {
        type: 'card',
        text:
          '✈️ *Travel Flow Steps:*\n'
          + '1. start travel\n'
          + '2. select destination\n'
          + '3. destination chosen\n'
          + '4. interests\n'
          + '5. dates\n'
          + '6. budget\n'
          + '7. hotel\n'
          + '8. confirm travel\n'
          + '9. travel booked'
      },
       
    ]
  };
   
 
app.post('/chat', (req, res) => { const message = req.body.message?.toLowerCase(); 
    const sessionId = req.body.sessionId;
 
if (!sessionId) { return res.status(400).json({ error: 'Missing sessionId' }); }
 
if (message === 'help') { 
    return res.json({ fields: helpFlow['help'] });
 }
// Initialize session 
    if (!sessionState[sessionId]) { 
        
    if (message === 'start bank') { 
        sessionState[sessionId] = { 
            flow: 'bank', stepIndex: 0 };
         } else if (message === 'start trade') { 
            sessionState[sessionId] = { 
                flow: 'trade', stepIndex: 0
             }; 
            } else if (message === 'start travel') { 
                sessionState[sessionId] = { flow: 'travel', stepIndex: 0 };
              
            } else { return res.json({ fields:
                 [{ type: 'text', text: '🤖 Try: start bank | start trade | start travel | help' }] })
                 ; } } else { sessionState[sessionId].stepIndex++; }
 
const { flow, stepIndex } = sessionState[sessionId]; const stepKey = flow === 'bank' ? bankSteps[stepIndex] : flow === 'trade' ? tradeSteps[stepIndex] : flow === 'travel' ? travelSteps[stepIndex] : null;
 
if (!stepKey) { return res.json({ fields: [{ type: 'text', text: '✅ Flow complete.' }] }); }
 
const fields = flow === 'bank' ? bankFlow[stepKey] : flow === 'trade' ? tradeFlow[stepKey] : flow === 'travel' ? travelFlow[stepKey] : [];
 
res.json({ fields }); });
 
 
app.listen(PORT, () => {
    console.log(`🟢 Node.js chatbot API running at http://localhost:${PORT}`);
    });
 
 
 //  ********** FOR POLLLINGGGGG ************


// const express = require('express');
// const cors = require('cors');
// const app = express();
// const port = 8080;
 
// app.use(cors());
// app.use(express.json());
 
// let latestPayload = null;
 
// app.post('/inbox', (req, res) => {
//   latestPayload = req.body;
//   console.log('Payload received:', latestPayload);
//   res.send({ status: 'received' });
// });
 
// app.get('/poll', (req, res) => {
//   if (latestPayload) {
//     const response = latestPayload;
//     latestPayload = null; // clear after sending once
//     res.json(response);
//   } else {
//     res.json({ fields: [] });
//   }
// });
 
// app.listen(port, () => {
//   console.log(`Server listening at http://localhost:${port}`);
// });
 
 //  ********** FOR POLLLINGGGGG ************
