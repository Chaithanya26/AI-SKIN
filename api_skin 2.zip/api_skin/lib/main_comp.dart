
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:fl_chart/fl_chart.dart';
 
Widget buildComponent(Map<String, dynamic> item, BuildContext context, void Function(String) sentToBot) {
  final isUser = item['from'] == 'user';
  Widget content;
 
  switch (item['type']) {
    case 'text':
      content = Text(item['text'], style: TextStyle( color: isUser? Colors.black87 : Colors.white, fontSize: 16),);
      break;

      case 'form':
  content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: (item['fields'] as List)
          .map<Widget>((subField) => buildComponent(Map<String, dynamic>.from(subField), context, sentToBot))
          .toList(),
  
  );
break;
 
    case 'card':
      content = Card(
        color:  Colors.blue,
       child:  ListTile(
          leading: const Icon(Icons.account_balance),
          title: Text(item['text'], style: TextStyle( color:  Colors.white, fontSize: 12)),
        ),
        
      );
      break;
 case 'switch':
  content = StatefulBuilder(
    builder: (context, setState) {
      bool isOn = item['value'] == true;
      return SwitchListTile(
        title: Text(item['text'] ?? 'Toggle', style: TextStyle( color:  Colors.white, fontSize: 12)),
        value: isOn,
        onChanged: (val) => setState(() => isOn = val),
      );
    },
  );
  break;

    case 'dropdown':
      String? selected;
      content = StatefulBuilder(
        builder: (context, setState) => DropdownButtonFormField(
  
          decoration: InputDecoration(labelText: item['label'],labelStyle: TextStyle(color: Colors.white), hintStyle: TextStyle(color: Colors.white)),
          items: (item['options'] as List)
              .map((opt) => DropdownMenuItem(
                    value: opt['value'],
                    child: Text(opt['label'], style: TextStyle( color:  Colors.white, fontSize: 12), ),
                  
                  ))
              .toList(),
          onChanged: (val) =>
          {
             setState(() { 
            selected = val.toString();
            sentToBot(val.toString());
            }),
          }
        ),
      );
      break;
 
    case 'radio_group':
    print("jadjadna $item");
      String? selected;
      content = StatefulBuilder(
        builder: (context, setState) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: (item['options'] as List).map<Widget>((opt) {
            return RadioListTile(
              title: Text(opt['label'], style: TextStyle( color:  Colors.white, fontSize: 12)),
              value: opt['value'],
              groupValue: selected,
              fillColor: WidgetStateProperty.all<Color>(Color(0XFF0050A0)),
              tileColor: Colors.white ,
              activeColor: Colors.white,
              onChanged: (val) => {
               setState(() { 
            selected = val.toString();
            sentToBot(val.toString());
            }),
            }
            );
          }).toList(),
        ),
      );
      break;
 
    case 'checkbox_group':
      Map<String, bool> selected = {
        for (var opt in item['options']) opt['value']: false
      };
      content = StatefulBuilder(
        builder: (context, setState) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: item['options'].map<Widget>((opt) {
            return CheckboxListTile(
              title: Text(opt['label'], style: TextStyle( color:  Colors.white, fontSize: 12)),
              fillColor: WidgetStateProperty.all<Color>(Color(0XFF0050A0)),
              value: selected[opt['value']],
              
              onChanged: (val) => {
                setState(() {
                selected[opt['value']] = val ?? false;
                sentToBot(opt['value']);
              }),
              }
              
             
            );
          }).toList(),
        ),
      );
      break;
 
    case 'slider':
      double value = (item['value'] as num).toDouble();
      content = StatefulBuilder(
        builder: (context, setState) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${item['label']} (${value.round()})', style: TextStyle( color:  Colors.white, fontSize: 12)),
            Slider(
              activeColor: Colors.blueGrey,
              value: value,
              min: (item['min'] as num).toDouble(),
              max: (item['max'] as num).toDouble(),
              divisions: item['dCivisions'],
              onChanged: (val) => {
                 setState(() {
                  value = val;
                sentToBot(value.toString());
              }),
                setState(() => value = val)
                },
            )
          ],
        ),
      );
      break;
 
    case 'textfield':
      content = TextField(
        decoration: InputDecoration(
          labelText: item['label'],
          labelStyle: TextStyle(color: Colors.white),
        ),
        style: TextStyle(color: Colors.white),
         onSubmitted: sentToBot
         );
      break;
 
 case 'button':
  content = Padding(
    
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: ElevatedButton(
    
      onPressed: () {
        // Example: collect form values here later if needed
         if (context != null) {
         ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("✅ ${item['action']}", style: TextStyle( color:  Colors.white, fontSize: 12))));
         }
               sentToBot(item['action']);
        print("Button clicked: ${item['text']}");
      },
      child: Text(item['text'] ?? 'Submit', style: TextStyle( color: Colors.black, fontSize: 12)),
    ),
  );
    
 
    case 'alert':
     content = const SizedBox();
      if (context != null && item['__shown'] != true) {
        item['__shown'] == true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: Text(item['title'], style: TextStyle( color: Colors.white, fontSize: 12)),
              content: Text(item['message'], style: TextStyle( color:  Colors.white, fontSize: 12)),
              actions: [
                TextButton(
                  onPressed: () => {
                    sentToBot(item['action']),
                    Navigator.pop(context)
                    },
                  child: const Text('OK'),
                )
              ],
            ),
          );
        });
      }
      // content = const SizedBox(); // Don't show alert inside chat
      break;
    case 'image':
  content = ClipRRect(
    borderRadius: BorderRadius.circular(8),
child: Image.network(
      item['url'],
      width: 200,height: 200,
      fit: BoxFit.fill,
      errorBuilder: (context, error, stackTrace) {
        return Text('⚠️ Failed to load image', style: TextStyle( color:  Colors.white, fontSize: 12));
      },
    ),
  );
  break;
  case 'shimmer':
  content= Shimmer.fromColors(
    baseColor: Colors.red.shade300,
    highlightColor: Colors.red,
    child: Container(
      width: double.infinity,
      height: 20,
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 8),
    ),
  );
  break;
  case 'chart':
  content= SizedBox(
    height: 200,
    child: BarChart(
      BarChartData(
        barGroups: List.generate(
          (item['data'] as List).length,
          (i) => BarChartGroupData(x: i, barRods: [
            BarChartRodData(toY: (item['data'][i] as num).toDouble(), color: Colors.blue)
          ]),
        ),
      ),
    ),
  );

break;
  case 'graph':
  content = ClipRRect(
    borderRadius: BorderRadius.circular(8),
child: Image.network(
      item['url'],
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) {
        return Text('⚠️ Failed to load image', style: TextStyle( color: isUser? Colors.black87 : Colors.white, fontSize: 12));
      },
    ),
  );
  break;
 
    default:
      content = const SizedBox.shrink();
  }

  return Align(
    alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      width: 300,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: isUser ? userMessageDecoration() :  botMessageDecoration(item['type']),
      child: content
      ),
   
  );
}

BoxDecoration userMessageDecoration() {
  return const BoxDecoration(
    gradient: LinearGradient(
      colors: [Color(0xFFE3F2FD), Color(0xFFBBDEFB)], // Purple shades
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    borderRadius: BorderRadius.only(
      topLeft: Radius.circular(16),
      topRight: Radius.circular(16),
      bottomLeft: Radius.circular(16),
    ),
    boxShadow: [
      BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2)),
    ],
  );
}
 
BoxDecoration? botMessageDecoration(String type) {
  
  if(type == 'card' || type == 'form'){
    print(type);
  return null;
  }else{
      print("object");
     return const BoxDecoration(
    gradient: LinearGradient(
      colors: [Color(0xFF1565C0), Color(0xFF1E88E5)], // Royal blue
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    borderRadius: BorderRadius.only(
      topLeft: Radius.circular(16),
      topRight:Radius.circular(16),
      bottomRight: Radius.circular(16),
    ),
    boxShadow: [
      BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 2)),
    ],
  );
  

  }
  
}
 
 
 
//   return Align(
//     alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
//     child: Container(
//       margin: const EdgeInsets.symmetric(vertical: 6),
//       padding: const EdgeInsets.all(12),
//       decoration: BoxDecoration(
//         color: isUser ? Colors.blue[100] : Colors.grey[200],
//         borderRadius: BorderRadius.circular(14),
//       ),
//       constraints: const BoxConstraints(maxWidth: 320),
//       child: content,
//     ),
//   );
// }

 

