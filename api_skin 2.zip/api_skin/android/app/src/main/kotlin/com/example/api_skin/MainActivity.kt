package com.example.api_skin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
